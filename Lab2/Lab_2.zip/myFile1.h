
#include <iostream>
using namespace std;
const int size_tab = 10; // number of elements of the array
void sort(int a[], int b);