/*Card.h*/
#include<iostream>
using namespace std; 
#include <cassert> //for assert()

enum color{club, diamond, heart, spade};
class Card{ 
	public: 
		Card(color c=club, int v=1) ; 
		int value(){return val;}
		void write() {
			cout << "Color: " << col << "\n"; cout << "Value: " << val << "\n";};   //print value of card
	private : 
		color col; 
		int val; 
};

/*Constructor*/
Card::Card(color c, int v) {
	assert (v>= 1 && v<= 13) ;//we use a standard function void assert (int expression)
							  //which indicates an error message if the expression is false.
	col=c;
	val=v; 
}

